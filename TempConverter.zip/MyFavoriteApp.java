package sample;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class MyFavoriteApp extends Application{

    //Scene
    Scene scene;
    //default variables
    double rightToLeft = 0.0; //Outcome when converting from right to left
    double leftToRight = 0.0; //Outcome when converting from left to right
    String formula = "";
    //Main
    public static void main(String[] args){
        launch(args);
    }
    //Method to call upon to convert from left to right or right to left
    //For right to left, we will simply switch our first two parameters compared to left to right
    public static double convert(String leftBox, String rightBox, double input){
        double result = 0; //initialize variable with default value
        //All possible conversions
        if(leftBox.compareToIgnoreCase("celsius") == 0 && rightBox.compareToIgnoreCase("fahrenheit") == 0){
        //Celsius to Fahrenheit
            result = (((9*input)/5) + 32);
        }
        else if(leftBox.compareToIgnoreCase("fahrenheit") == 0 && rightBox.compareToIgnoreCase("celsius") == 0){
        //Fahrenheit to Celsius
            result = (5*(input - 32))/9;
        } else if(leftBox.compareToIgnoreCase("celsius") == 0 && rightBox.compareToIgnoreCase("celsius") == 0){
           //Celsius to Celsius
            result = input;
        } else if(leftBox.compareToIgnoreCase("fahrenheit") == 0 && rightBox.compareToIgnoreCase("fahrenheit") == 0){
          //Fahrenheit to Fahrenheit
            result = input;
        } else if(leftBox.compareToIgnoreCase("celsius") == 0 && rightBox.compareToIgnoreCase("kelvin") == 0){
            //Celsius to Kelvin
            result = input + 273.15;
        } else if(leftBox.compareToIgnoreCase("kelvin") == 0 && rightBox.compareToIgnoreCase("celsius") == 0){
            //Kelvin to Celsius
            result = input - 273.15;
        } else if(leftBox.compareToIgnoreCase("kelvin") == 0 && rightBox.compareToIgnoreCase("kelvin") == 0){
            //Kelvin to Kelvin
            result = input;
        } else if(leftBox.compareToIgnoreCase("kelvin") == 0 && rightBox.compareToIgnoreCase("fahrenheit") == 0){
           //Kelvin to Fahrenheit
            result = ((9*(input - 273.15))/5 + 32);
        } else if(leftBox.compareToIgnoreCase("fahrenheit") == 0 && rightBox.compareToIgnoreCase("kelvin") == 0){
            //Fahrenheit to Kelvin
            result = (5*(input-32))/9 + 273.15;
        }
        return result;
    }



    //Start method
    @Override
    public void start(Stage primaryStage) throws Exception {
//Set title for window
        primaryStage.setTitle("Sequoia Temperature Converter");

//GUI components
        //left combo box, default: celsius
        ComboBox leftBox = new ComboBox();
        leftBox.getItems().add("Celsius");
        leftBox.getItems().add("Fahrenheit");
        leftBox.getItems().add("Kelvin");
        leftBox.setValue("Celsius");
        leftBox.setPadding(new Insets(0,0,0,5));
        leftBox.setStyle("-fx-font-weight: bold");
        //right combo box, default: fahrenheit
        ComboBox rightBox = new ComboBox();
        rightBox.getItems().add("Celsius");
        rightBox.getItems().add("Fahrenheit");
        rightBox.getItems().add("Kelvin");
        rightBox.setValue("Fahrenheit");
        rightBox.setPadding(new Insets(0,0,0,5));
        rightBox.setStyle("-fx-font-weight: bold");
        Label equalSign = new Label("=");
        TextField leftTxt = new TextField();
        TextField rightTxt = new TextField();
        Label formulaTxt = new Label();


//Convert on key press for left value
        leftTxt.setOnKeyTyped(ActionEvent -> {

    //Read input
                String input = leftTxt.getText();
                try{
                    if(input.compareTo("") !=0)
    //Parse input to double
                        rightToLeft = Double.parseDouble(input);
    //Call convert method and convert left to right
                    leftToRight = MyFavoriteApp.convert((String) leftBox.getValue(), (String) rightBox.getValue(), rightToLeft);
    //All possible formulas from left to right
                    if(rightBox.getValue() == "Celsius" && leftBox.getValue() == "Fahrenheit"){
                        formula = "Formula:   (5*(" + input + "\u00B0F - 32))/9" + " = " + leftToRight + "\u00B0C";
                    } else if(rightBox.getValue() == "Celsius" && leftBox.getValue() == "Celsius"){
                        formula = "Formula:   " + input + "\u00B0C" + " = " + leftToRight + "\u00B0C";
                    } else if(rightBox.getValue() == "Celsius" && leftBox.getValue() == "Kelvin"){
                        formula = "Formula:   " + input + "K - 273.15" + " = " + leftToRight + "\u00B0C";
                    } else if(rightBox.getValue() == "Fahrenheit" && leftBox.getValue() == "Celsius"){
                        formula = "Formula:   (((9*" + input  + "\u00B0C" + ")" + "/5) + 32)" + " = " + leftToRight + "\u00B0F";
                    } else if(rightBox.getValue() == "Fahrenheit" && leftBox.getValue() == "Kelvin"){
                        formula = "Formula:   (((9*(" + input  + "K - 273.15)" + ")" + "/5) + 32)" + " = " + leftToRight + "\u00B0F";
                    } else if(rightBox.getValue() == "Fahrenheit" && leftBox.getValue() == "Fahrenheit"){
                        formula = "Formula:   " + input + "\u00B0F" + " = " + leftToRight + "\u00B0F";
                    } else if(rightBox.getValue() == "Kelvin" && leftBox.getValue() == "Celsius") {
                        formula = "Formula:   " + input + "\u00B0C + 273.15" + " = " + leftToRight + "K";
                    } else if(rightBox.getValue() == "Kelvin" && leftBox.getValue() == "Fahrenheit") {
                        formula = "Formula:   (5*(" + input + "\u00B0F - 32))/9 + 273.15" + " = " + leftToRight + "K";
                    } else if(rightBox.getValue() == "Kelvin" && leftBox.getValue() == "Kelvin"){
                        formula = "Formula:   " + input + "K" + " = " + leftToRight + "K";
                    }
    //Display converted value + formula
                    rightTxt.setText(String.valueOf(leftToRight));
                    formulaTxt.setText(formula);
                }
                catch(Exception ex){
    //If things go wrong, error message

    //Creates object of alert class
                    Alert alert = new Alert(AlertType.INFORMATION);
                    alert.setHeaderText(null);
    //Display error
                    alert.setTitle("Error");
                    alert.setContentText("Error, enter a number.");
                    alert.showAndWait();
                }

        });

//Set right value on key type
        rightTxt.setOnKeyTyped(ActionEvent ->{
//take input from right value
            String input = rightTxt.getText();
            try{
                if(input.compareTo("") != 0)
//Parse input to double
                    leftToRight = Double.parseDouble(input);
//Call onConvert method and convert right to left, we switch our parameters this time to convert right to left
                rightToLeft = MyFavoriteApp.convert((String) rightBox.getValue(), (String) leftBox.getValue(), leftToRight);
//All possible formulas from right to left
                if(leftBox.getValue() == "Celsius" && rightBox.getValue() == "Fahrenheit"){
                    formula = "Formula:   (5*(" + input + "\u00B0F - 32))/9" + " = " + rightToLeft + "\u00B0C";
                } else if(leftBox.getValue() == "Celsius" && rightBox.getValue() == "Celsius"){
                    formula = "Formula:   " + input + "\u00B0C" + " = " + rightToLeft + "\u00B0C";
                } else if(leftBox.getValue() == "Celsius" && rightBox.getValue() == "Kelvin"){
                    formula = "Formula:   " + input + "K - 273.15" + " = " + rightToLeft + "\u00B0C";
                } else if(leftBox.getValue() == "Fahrenheit" && rightBox.getValue() == "Celsius"){
                    formula = "Formula:   (((9*" + input  + "\u00B0C" + ")" + "/5) + 32)" + " = " + rightToLeft + "\u00B0F";
                } else if(leftBox.getValue() == "Fahrenheit" && rightBox.getValue() == "Kelvin"){
                    formula = "Formula:   (((9*(" + input  + "K -273.15)" + ")" + "/5) + 32)" + " = " + rightToLeft + "\u00B0F";
                } else if(leftBox.getValue() == "Fahrenheit" && rightBox.getValue() == "Fahrenheit"){
                    formula = "Formula:   " + input + "\u00B0F" + " = " + rightToLeft + "\u00B0F";
                } else if(leftBox.getValue() == "Kelvin" && rightBox.getValue() == "Celsius") {
                    formula = "Formula:   " + input + "\u00B0C + 273.15" + " = " + rightToLeft + "K";
                } else if(leftBox.getValue() == "Kelvin" && rightBox.getValue() == "Fahrenheit") {
                    formula = "Formula:   (5*(" + input + "\u00B0F - 32))/9 + 273.15" + " = " + rightToLeft + "K";
                } else if(leftBox.getValue() == "Kelvin" && rightBox.getValue() == "Kelvin"){
                    formula = "Formula:   " + input + "K" + " = " + rightToLeft + "K";
                }
//Converted value + formula
                leftTxt.setText(String.valueOf(rightToLeft));
                formulaTxt.setText(formula);
            }
            catch(Exception ex){
//If things go wrong, we can catch it with an error message

//Create object of alert class
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setHeaderText("Invalid entry");
//Display error
                alert.setTitle("Error");
                alert.setContentText("Error, enter a number.");
                alert.showAndWait();
            }


        });


//GridPane Object to set components
        GridPane grid = new GridPane();
//Add components, second parameter x axis, third parameter y axis
        grid.add(leftBox, 1, 3);
        grid.add(leftTxt, 1, 1);
        grid.add(rightBox, 3, 3);
        grid.add(rightTxt, 3, 1);
        grid.add(equalSign, 2, 1);
        grid.add(formulaTxt, 1, 4);
//Set gaps between things
        grid.setHgap(30);
        grid.setVgap(10);
//Initialize Window, width 600, length 300
        scene = new Scene(grid,600, 300);

//Add Window to stage and show
        primaryStage.setScene(scene);
        primaryStage.show();

    }
}