package sample;

public class MyFavoriteAppMain {
    public static void main(String[] args) {
        MyFavoriteApp.main(args);
    }
}
